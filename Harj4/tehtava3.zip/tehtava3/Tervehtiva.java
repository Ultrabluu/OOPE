package tehtava3;

/*
 * Luento 6.
 *
 * Olio-ohjelmoinnin perusteet, Jorma Laurikkala.
 *
 * Rajapinta tervehtiville olioille.
 *
 */

public interface Tervehtiva {
   // Moikataan toteuttajan sopivaksi katsomalla tavalla.
   // public- ja abstract-m��reet saataisiin my�s automaattisesti. 
   public abstract void moikkaa();
}