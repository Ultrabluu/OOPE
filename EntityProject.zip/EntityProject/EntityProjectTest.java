/*
 * For testing the Entity project
 */

public class EntityProjectTest {
    
    public static void main (String[] args) {
        Pharah pharah = new Pharah(true);
        System.out.println(pharah.toString());
    }

}
