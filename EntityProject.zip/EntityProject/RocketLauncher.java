/* Models weapons> Rocket launcher generally.
 * Work very much in progress.
 * Rps = RoundsPerSecond
 */

public class RocketLauncher extends Weapon {
    
    private double rps;
    private double weaponDmg;
    private double reloadTime;
    
    

}
